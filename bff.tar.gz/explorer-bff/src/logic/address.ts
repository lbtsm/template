export function normalizeAddress(address: string) {
  // TODO(mendez) this can be better but it is good enough
  return address.toLowerCase()
}
