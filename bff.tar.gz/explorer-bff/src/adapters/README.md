Here goes all the code adapters, transforming one data type into another.
