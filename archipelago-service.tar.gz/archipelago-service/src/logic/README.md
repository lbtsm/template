Here goes all the unit-testable functions.
