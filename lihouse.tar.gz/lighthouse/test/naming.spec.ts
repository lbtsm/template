// Because of Bazel sandboxing, we need this for the time being
process.env.LIGHTHOUSE_STORAGE_LOCATION = '.'

// import { DAOClient, ServerMetadata } from '@dcl/catalyst-node-commons'
// import { lighthouseStorage } from '../src/config/simpleStorage'
// import { defaultNames, pickName } from '../src/misc/naming'
//
// declare let global: any

// const oldFetch = global.fetch
//
// const daoClient: DAOClient = {
//   async getAllServers(): Promise<Set<ServerMetadata>> {
//     return new Set([{ id: 'id', baseUrl: '0x...', owner: '0x...' }])
//   }
// } as DAOClient

// /*
// catalystCount(): Promise<BigNumber>;
//     catalystIds(input: BigNumber | string | number): Promise<Uint8Array>;
//     catalystById(id: Uint8Array): Promise<CatalystByIdResult>;
//  */
//
// const daoClient: DAOClient = {
//   async getAllServers(): Promise<Set<ServerMetadata>> {
//     return new Set([{ id: 'id', baseUrl: '0x...', owner: '0x...' }])
//   }
//   catalystCount(): Promise<BigNumber> {
//
//   }
//   catalystIds(input: BigNumber | string | number): Promise<Uint8Array> {
//
//   }
//
// } as DAOClient

// let existingName = 'fenrir'

// describe('picking a name', function () {
//   beforeAll(() => {
//     global.fetch = (input, init) => {
//       return Promise.resolve(new Response(`{"name": "${existingName}"}`))
//     }
//   })
//
//   afterAll(() => {
//     global.fetch = oldFetch
//   })
//
//   afterEach(async () => {
//     await lighthouseStorage.clear()
//   })
//
//   it('picks up a default name when the name is no in the DAO', async () => {
//     for (let i = 0; i < 100; i++) {
//       const name = await pickName(undefined, daoClient)
//
//       expect(name).not.toBe(existingName)
//       expect(defaultNames.includes(name)).toBe(true)
//
//       await lighthouseStorage.clear()
//     }
//   })
//
//   it('picks up a configured name when the name is not in the DAO', async () => {
//     for (let i = 0; i < 20; i++) {
//       const name = await pickName('rick,morty', daoClient)
//
//       expect(name).not.toBe(existingName)
//       expect(['rick', 'morty'].includes(name)).toBe(true)
//
//       await lighthouseStorage.clear()
//     }
//   })
//
//   it('tries to reuse the previous name', async () => {
//     const previousName = await pickName(undefined, daoClient)
//
//     const currentName = await pickName(undefined, daoClient)
//
//     expect(currentName).toBe(previousName)
//   })
//
//   it("doesn't reuse the previous name if it was taken", async () => {
//     const previousName = await pickName(undefined, daoClient)
//
//     existingName = previousName
//
//     const currentName = await pickName(undefined, daoClient)
//
//     expect(currentName).not.toBe(previousName)
//   })
//
//   it("fails if it can't use any of the names available", async () => {
//     try {
//       await pickName(existingName, daoClient)
//       fail()
//     } catch (e) {
//       expect(e.message).toBe('Could not set my name! Names taken: ' + existingName)
//     }
//   })
// })
