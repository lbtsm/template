import { lighthouseStorage } from '../config/simpleStorage'
import { CatalystContract } from 'abeyworld-catalyst-contracts'

export const defaultNames = [
  'zeus',
  'poseidon',
  'athena',
  'hera',
  'hephaestus',
  'aphrodite',
  'hades',
  'hermes',
  'artemis',
  'thor',
  'loki',
  'odin',
  'freyja',
  'fenrir',
  'heimdallr',
  'baldr'
]

export async function pickName(configuredNames: string | undefined, contract: CatalystContract) {
  // const existingNames: string[] = await getLighthousesNames(daoClient)
  const existingNames: Set<string | undefined> = await getLighthouseExistNames(contract)

  console.log('existingNames ------- ', existingNames)

  if (typeof configuredNames === 'undefined') {
    // We use the stored name only if no name has been configured
    const previousName = await lighthouseStorage.getString('name')
    if (previousName && !existingNames.has(previousName)) {
      return previousName
    } else if (previousName) {
      console.warn('Could not reuse previous name because another lighthouse in DAO already has it: ' + previousName)
    }
  }

  const namesList = (configuredNames?.split(',')?.map((it) => it.trim()) ?? defaultNames).filter(
    (it) => !existingNames.has(it)
  )

  if (namesList.length === 0) throw new Error('Could not set my name! Names taken: ' + existingNames)

  const pickedName = namesList[Math.floor(Math.random() * namesList.length)]

  await lighthouseStorage.setString('name', pickedName)

  return pickedName
}

async function getLighthouseExistNames(contract: CatalystContract): Promise<Set<string | undefined>> {
  // Check count on the list
  const count = (await contract.catalystCount()).toNumber()
  console.log('getLighthouseExistNames count ----------- ', count)
  const catalystNamePromises: Promise<string | undefined>[] = []
  for (let i = 0; i < count; i++) {
    const id = await contract.catalystIds(i)
    const { domain } = await contract.catalystById(id)
    console.log('domain ----------- ', domain)
    const baseUrl = domain.trim()
    console.log('baseUrl ----------- ', baseUrl)

    catalystNamePromises.push(getName(baseUrl))
  }

  return new Set(await Promise.all(catalystNamePromises))
}

async function getName(server: string): Promise<string> {
  //Timeout is an option that is supported server side, but not browser side, so it doesn't compile if we don't cast it to any
  try {
    const statusResponse = await fetch(`${server}/comms/status`, { timeout: 5000 } as any)
    const json = await statusResponse.json()

    if (json.name) {
      return json.name
    }

    throw new Error(`Response did not have the expected format. Response was: ${JSON.stringify(json)}`)
  } catch (e) {
    console.warn(`Error while getting the name of ${server}, `, e.message)
    throw e
  }
}
