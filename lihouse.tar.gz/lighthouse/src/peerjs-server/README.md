# Catalyst PeerJS Server Implementation

Based upon Peer JS Server: https://github.com/peers/peerjs-server

Originally forked in here: https://github.com/decentraland/peerjs-server
